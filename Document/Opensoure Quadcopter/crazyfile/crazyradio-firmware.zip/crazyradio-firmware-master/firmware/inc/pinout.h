#ifndef __PINOUT_H__
#define __PINOUT_H__

#define CR_LED_RED   2
#define CR_LED_GREEN 4

#define CRPA_LED_RED   2
#define CRPA_LED_GREEN 0
#define CRPA_PA_RXEN   4

#endif /* __PINOUT_H__ */

