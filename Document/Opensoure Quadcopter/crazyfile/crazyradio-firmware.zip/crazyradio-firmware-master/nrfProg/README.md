# nrfProg - nRF24LU1p SPI programmer.

Type 'nrfProg help' for help.
