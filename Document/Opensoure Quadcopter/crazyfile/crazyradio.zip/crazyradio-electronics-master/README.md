# Crazyradio Electronics
Datasheets and KiCad project files for the Crazyradio electronics design.

For more information see the [wiki](https://wiki.bitcraze.io/projects:crazyradio:index)
